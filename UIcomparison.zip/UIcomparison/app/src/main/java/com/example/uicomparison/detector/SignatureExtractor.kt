package com.example.uicomparison.detector

import android.view.accessibility.AccessibilityEvent

object SignatureExtractor {

    fun fromEvent(event: AccessibilityEvent): Map<String, String?> {

        val src = event.source

        return mapOf(
            "package" to event.packageName?.toString(),
            "className" to event.className?.toString(),
            "text" to event.text?.joinToString(),
            "contentDescription" to src?.contentDescription?.toString(),
            "viewId" to src?.viewIdResourceName
        )
    }
}
