package com.example.uicomparison

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.example.uicomparison.detector.*

class StageAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {

        if (!RecordingController.isRecording) return

        val action = ActionNormalizer.normalize(
            event.eventType,
            event.className?.toString(),
            event.text?.joinToString(),
            event.contentDescription?.toString(),
            event.packageName?.toString()
        )

        val sig = SignatureExtractor.fromEvent(event)  // Map<String, String?>

        CurrentSignatureHolder.update(sig, action)

        // 🔥 여기 수정
        StageAnalyzer.autoAnalyze(sig)
    }



    override fun onInterrupt() {}
}
