package com.example.uicomparison.detector

object ActionNormalizer {

    fun normalize(eType: Int, className: String?, text: String?, cDesc: String?, pkg: String?): String {

        return when {
            eType == 32 -> "APP_OPEN"
            eType == 4096 -> "SCREEN_TRANSITION"
            eType == 1 -> "SELECT"
            className?.contains("EditText") == true -> "INPUT"
            text?.contains("재생") == true || cDesc?.contains("play", true) == true -> "EXECUTE"
            else -> "SCREEN_TRANSITION"
        }
    }
}
