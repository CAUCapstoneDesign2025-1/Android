package com.example.uicomparison

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔥 앱 실행 시 오버레이 권한 체크
        checkOverlayPermission()

        setContent {
            Surface {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text("UI Comparison", style = MaterialTheme.typography.headlineSmall)

                    Spacer(modifier = Modifier.height(20.dp))

                    // 접근성 설정 열기
                    Button(onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        startActivity(intent)
                    }) {
                        Text("접근성 서비스 켜기")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // 단계 판단 화면
                    Button(onClick = {
                        startActivity(Intent(this@MainActivity, StageActivity::class.java))
                    }) {
                        Text("단계 판단 화면으로 이동")
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // 🔥 플로팅 버튼 실행
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                            !Settings.canDrawOverlays(this@MainActivity)
                        ) {
                            Toast.makeText(
                                this@MainActivity,
                                "오버레이 권한을 허용해주세요.",
                                Toast.LENGTH_SHORT
                            ).show()
                            checkOverlayPermission()
                        } else {
                            startService(
                                Intent(
                                    this@MainActivity,
                                    FloatingWidgetService::class.java
                                )
                            )
                        }
                    }) {
                        Text("플로팅 버튼 켜기")
                    }
                }
            }
        }
    }

    // 🔥 오버레이 권한 체크 + 요청
    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }
    }
}
