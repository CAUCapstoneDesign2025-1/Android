package com.example.uicomparison

object RecordingController {
    @Volatile
    var isRecording: Boolean = false
}
