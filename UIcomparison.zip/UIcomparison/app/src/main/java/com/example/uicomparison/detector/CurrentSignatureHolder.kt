package com.example.uicomparison.detector

object CurrentSignatureHolder {

    var lastSignature: Map<String, String?> = emptyMap()
    var lastAction: String = "SCREEN_TRANSITION"

    fun update(signature: Map<String, String?>, action: String) {
        lastSignature = signature
        lastAction = action
    }
}
