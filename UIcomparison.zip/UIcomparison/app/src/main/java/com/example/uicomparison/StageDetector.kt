package com.example.uicomparison

import java.util.ArrayDeque

object StageDetector {

    private val buffer = ArrayDeque<String>()

    fun push(action: String) {
        buffer.addLast(action)
        if (buffer.size > 5) buffer.removeFirst()
    }

    fun detect(): String {
        if (buffer.isEmpty()) return "NO_ACTIVITY"

        val a = buffer.toList()

        val hasOpen = "APP_OPEN" in a
        val hasBrowse = "BROWSE" in a
        val selectCount = a.count { it == "SELECT" }
        val hasInput = "INPUT" in a
        val hasExecute = "EXECUTE" in a
        val hasExit = "EXIT" in a

        return when {
            hasExit -> "EXIT"
            hasExecute -> "EXECUTE"
            hasInput -> "INPUT"
            selectCount >= 2 -> "SELECT"
            hasBrowse -> "BROWSE"
            hasOpen -> "APP_OPEN"
            else -> "UNKNOWN_STAGE"
        }
    }
}
