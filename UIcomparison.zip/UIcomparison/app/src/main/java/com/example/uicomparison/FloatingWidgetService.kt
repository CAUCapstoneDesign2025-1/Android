package com.example.uicomparison

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        params.x = 200
        params.y = 300

        val startBtn = floatingView.findViewById<Button>(R.id.btnStart)
        val stopBtn = floatingView.findViewById<Button>(R.id.btnStop)
        val closeBtn = floatingView.findViewById<ImageView>(R.id.btnClose)

        // START → 분석 시작
        startBtn.setOnClickListener {
            RecordingController.isRecording = true
            Toast.makeText(this, "▶ 분석 시작", Toast.LENGTH_SHORT).show()
        }

        // STOP → 분석 중지
        stopBtn.setOnClickListener {
            RecordingController.isRecording = false
            Toast.makeText(this, "■ 분석 중지", Toast.LENGTH_SHORT).show()
        }

        // 닫기
        closeBtn.setOnClickListener {
            stopSelf()
        }

        // 드래그 기능
        floatingView.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(floatingView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.removeView(floatingView)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
