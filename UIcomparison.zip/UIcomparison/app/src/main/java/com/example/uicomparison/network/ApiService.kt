package com.example.uicomparison.network

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body
import retrofit2.http.Path

interface ApiService {

    @GET("/api/get_steps/{sessionId}")
    fun getSteps(@Path("sessionId") sessionId: String): Call<StepResponse>

    @POST("/api/status")
    fun sendStatus(@Body body: Map<String, String>): Call<Void>

}
