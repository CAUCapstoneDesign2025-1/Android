package com.example.uicomparison.detector

import android.util.Log
import com.example.uicomparison.network.StepData

class StepMatcher {

    // 범용 이벤트 기반 비교 규칙
    private val matchRules: Map<Int, List<String>> = mapOf(

        // SELECT (클릭)
        1 to listOf("viewId", "className", "packageName"),

        // INPUT (키 입력 / 텍스트 입력)
        2 to listOf("viewId", "className", "packageName"),
        16 to listOf("viewId", "className", "packageName"),

        // SCREEN TRANSITION
        4096 to listOf("packageName", "className"),

        // APP OPEN
        32 to listOf("packageName")
    )

    /**
     * StepData와 Current Signature 비교
     */
    fun matchSingleStep(step: StepData, sig: Map<String, String?>): Boolean {

        // 이벤트 타입별 규칙 선택 (없으면 기본 규칙)
        val requiredFields = matchRules[step.eventType]
            ?: listOf("viewId", "className", "packageName")

        var allMatch = true
        val debug = StringBuilder("\n--- Step 비교 결과 (EventType=${step.eventType}) ---\n")

        for (field in requiredFields) {
            val stepValue = getField(step, field)
            val sigValue = sig[field]
            val match = stepValue == sigValue

            debug.append("$field: [$stepValue] == [$sigValue] → match=$match\n")
            if (!match) allMatch = false
        }

        debug.append("최종 결과 = $allMatch\n")
        Log.i("StepMatcher", debug.toString())

        return allMatch
    }

    /**
     * StepData 필드 Getter
     */
    private fun getField(step: StepData, field: String): String? {
        return when (field) {
            "eventType" -> step.eventType.toString()
            "packageName" -> step.packageName
            "className" -> step.className
            "text" -> step.text
            "contentDescription" -> step.contentDescription
            "viewId" -> step.viewId
            "bounds" -> step.bounds
            else -> null
        }
    }
}
