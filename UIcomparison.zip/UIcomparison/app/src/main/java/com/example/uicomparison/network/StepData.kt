package com.example.uicomparison.network

data class StepData(
    val step: Int,
    val eventType: Int,
    val packageName: String?,
    val className: String?,
    val text: String?,
    val contentDescription: String?,
    val viewId: String?,
    val bounds: String?
)

data class StepResponse(val steps: List<StepData>)
