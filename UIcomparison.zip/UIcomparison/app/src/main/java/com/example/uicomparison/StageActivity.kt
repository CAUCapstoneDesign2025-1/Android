package com.example.uicomparison

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.uicomparison.network.RetrofitClient
import com.example.uicomparison.network.StepData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class StageActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StageScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StageScreen() {

    var sessionId by remember { mutableStateOf("session_20251119_105524") }
    var steps by remember { mutableStateOf(listOf<StepData>()) }
    var selectedStepIndex by remember { mutableStateOf(-1) }

    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .padding(24.dp)
            .fillMaxSize()
    ) {

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = sessionId,
            onValueChange = { sessionId = it },
            label = { Text("Session ID") }
        )

        Spacer(Modifier.height(16.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    val resp = withContext(Dispatchers.IO) {
                        RetrofitClient.instance.getSteps(sessionId).execute()
                    }

                    if (resp.isSuccessful) {
                        steps = resp.body()?.steps ?: emptyList()
                        Log.i("StageActivity", "불러온 Step 개수 = ${steps.size}")
                    }
                }
            }
        ) {
            Text("커리큘럼 Step 불러오기")
        }

        Spacer(Modifier.height(24.dp))

        if (steps.isNotEmpty()) {

            var expanded by remember { mutableStateOf(false) }

            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    readOnly = true,
                    value = if (selectedStepIndex == -1) "" else "Step ${selectedStepIndex + 1}",
                    onValueChange = {},
                    label = { Text("선택된 Step") },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )

                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    steps.forEachIndexed { index, step ->
                        DropdownMenuItem(
                            text = { Text("Step ${step.step}") },
                            onClick = {
                                selectedStepIndex = index
                                expanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (selectedStepIndex != -1) {
                        StageAnalyzer.targetStep = steps[selectedStepIndex]
                        StageAnalyzer.targetStepIndex = selectedStepIndex

                        Log.i("StageActivity", "선택된 스텝 = ${steps[selectedStepIndex]}")
                    }
                }
            ) {
                Text("Step 선택")
            }
        }
    }
}
