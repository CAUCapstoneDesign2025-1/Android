package com.example.uicomparison

import android.util.Log
import com.example.uicomparison.detector.StepMatcher
import com.example.uicomparison.network.StepData
import com.example.uicomparison.network.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object StageAnalyzer {

    var targetStep: StepData? = null
    var targetStepIndex: Int = -1

    fun autoAnalyze(sig: Map<String, String?>?) {

        val step = targetStep
        if (step == null) {
            send("error", "Step이 선택되지 않았습니다. StageActivity에서 Step 선택 버튼을 누르세요.")
            return
        }

        if (sig == null) {
            send("error", "이벤트 시그니처 없음.")
            return
        }

        val matcher = StepMatcher()
        val match = matcher.matchSingleStep(step, sig)

        if (match) {
            send("ok", "현재 단계는 선택한 Step ${step.step}과 정확히 일치합니다!")
        } else {
            send("error", "현재 단계가 Step ${step.step}과 일치하지 않습니다!")
        }
    }

    private fun send(status: String, msg: String) {
        val body = mapOf("status" to status, "message" to msg)

        RetrofitClient.instance.sendStatus(body)
            .enqueue(object : Callback<Void> {
                override fun onResponse(call: Call<Void>, response: Response<Void>) {
                    Log.i("Server", "메시지 전송 성공: $msg")
                }
                override fun onFailure(call: Call<Void>, t: Throwable) {
                    Log.e("Server", "전송 실패: ${t.message}")
                }
            })
    }
}
